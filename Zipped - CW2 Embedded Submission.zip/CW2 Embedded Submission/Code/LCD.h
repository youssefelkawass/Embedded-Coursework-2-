#ifndef LCD_H
#define LCD_H

#include <stdint.h>

void LCD_init(void);
void LCD_command(uint8_t cmd);
void LCD_write_char(char c);
void LCD_write_string(const char* str);
void LCD_set_cursor(uint8_t row, uint8_t col);

#endif
