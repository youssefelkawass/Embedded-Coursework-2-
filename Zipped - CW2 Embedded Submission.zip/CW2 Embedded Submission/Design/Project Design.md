# Detailed Design Document

|        Author        | Status  | Version | Date       |
|----------------------|---------|---------|------------|
| Youssef Amir Elkawas | Final   | 1.0     | 13/11/2025 |

---

## Introduction

This document describes the detailed design of the **CW2 Human Machine Interface (HMI)** for temperature monitoring using an ATmega328P-based Arduino board.  
The module provides a 16x2 LCD interface, four navigation buttons, and an alarm LED that warns when the measured temperature leaves a configurable safe range.

### Purpose

- Provide a clear description of the software architecture and module responsibilities.
- Document how the LCD, ADC, buttons, and LED are integrated to implement the required behaviour.
- Serve as a reference for maintenance, further development, and code review.

### Scope

- The design covers the embedded firmware that runs on the ATmega328P for CW2.
- Hardware such as the temperature sensor, buttons, LCD and LED are used as peripherals and are referenced where needed.
- The design does **not** cover PCB design or external data logging; it focuses purely on on-board HMI functionality.

---



## Architectural Overview

This section shows how the CW2 HMI module fits into the overall software architecture.

The application is split into three logical layers:

- **HMI Application** – main control loop, limit handling, and alarm logic.
- **MCU Layer** – LCD and button handling built directly on top of MCU resources.
- **MCAL (Microcontroller Abstraction Layer)** – low level drivers for ADC and digital I/O.

```plantuml
@startuml

rectangle "CW2_HMI" #orange {

    rectangle MainApp

    rectangle MCU #green {
        rectangle LCD
        rectangle Buttons
    }

    rectangle MCAL #skyblue {
        rectangle ADC
    }
}

rectangle Potentiometer as POT
POT --> ADC : analog voltage
ADC --> MainApp : temperature value
Buttons --> MainApp : user input
MainApp --> LCD : show Temp, LL, LH, status

@enduml

```
### Assumptions & Constraints
```plantuml
@startuml
start

:Init Modules;
note right
- Initialize LCD
- Initialize ADC
- Initialize Buttons
end note

:Configure System;
note right
- Set default LL and LH
- Clear LED status
end note

repeat
  :Read Potentiometer (ADC);
  :Update Temperature Value;

  if (Temp < LL or Temp > LH?) then (Yes)
      :Turn LED ON;
  else (No)
      :Turn LED OFF;
  endif

  :Show Temp, LL, LH, Status on LCD;

  if (Button Pressed?) then (Yes)
      if (UP?) then (Increase LH)
      else if (DOWN?) then (Decrease LH)
      else if (RIGHT?) then (Increase LL)
      else if (LEFT?) then (Decrease LL)
      else if (SELECT?) then (Reset LL/LH)
      endif
  endif
repeat while (System Running?)

stop
@enduml
```



# Functional Description

This chapter describes the software functionality implemented in the CW2 HMI module.  
The module is responsible for reading the potentiometer value, handling the user-defined limits, updating the LCD, and controlling the LED alarm.

The following sections describe the main processing performed by each logical part of the software.

---

## Main Application (HMI Layer)

The Main Application contains the primary control loop and executes the following functions:

### 1. System Initialization
- Initializes the ADC module.
- Initializes the LCD display.
- Initializes the input buttons.
- Ensures all system variables (LL, LH, status flag) start in known states.

### 2. Read Potentiometer Value
- Requests an ADC conversion from the MCAL layer.
- Receives a 0–1023 range digital value.
- Converts it to a meaningful display value (0–100% or equivalent scaled value).

### 3. User Input Handling
- Reads button presses from the MCU layer.
- Allows the user to:
  - Increase or decrease the Low Limit (LL).
  - Increase or decrease the High Limit (LH).
  - Acknowledge or reset alarm status (if designed).

### 4. Limit & Alarm Logic
- Compares the potentiometer value against the user-defined limits:
  - If value < LL → Low Alarm state.
  - If value > LH → High Alarm state.
  - Otherwise → Normal state.
- Controls the LED alarm output based on the active state.

### 5. LCD Display Handling
The Main Application updates the LCD with:
- Current potentiometer reading.
- Current LL and LH values.
- System status (“LOW”, “HIGH”, “NORMAL”).

Updates occur periodically to maintain responsiveness.

---

## MCU Layer

The MCU layer provides hardware-related interface functions for LCD and buttons.

### LCD
- Displays formatted strings sent by the Main Application.
- Handles cursor positioning and line selection.
- Clears and refreshes the screen when requested.

### Buttons
- Reads button states and debounces input.
- Returns simple logical values such as UP, DOWN, or SET.
- No internal decision logic — all decisions are made in the Main Application.

---

## MCAL Layer

The MCAL layer contains the ADC driver.

### ADC
- Configures ADC reference, resolution, and input channel.
- Starts conversion upon request.
- Returns the full 10-bit ADC value to the Main Application.
- Performs no scaling or interpretation of values.

---

## LED Alarm Output

The LED is controlled directly by the Main Application:
- ON when the system is in a High or Low alarm state.
- OFF when the measured value is within limits.

No DIO driver file is used; LED control is performed through a simple digital output pin in the Main Application.

# Implementation of the Module

This chapter describes the detailed internal implementation of the CW2 HMI module.  
The system is implemented as multiple files: Main.ino, ADC module, LCD module, and Buttons module.  
Each module has a dedicated responsibility and is integrated into the final solution.

---

## 1. Main Application (Main.ino)

### Responsibilities
- Runs the main program loop.
- Reads ADC value from potentiometer.
- Reads buttons to modify LL and LH.
- Controls the LED alarm depending on limits.
- Updates LCD with all system information.

### Main Functions

#### `void setup()`
- Initializes ADC
- Initializes LCD
- Configures button inputs
- Configures LED output
- Sets default LL and LH values

#### `void loop()`
Executed continuously:
1. Reads potentiometer value using `ADC_Read()`
2. Reads user buttons for adjusting LL/LH
3. Compares current value with limits
4. Sets alarm LED based on status
5. Updates the LCD using `LCD_ShowValues()`

---

## 2. ADC Module (ADC.h / ADC.ino)

### Responsibilities
- Provides low-level access to the ADC hardware.
- Reads analog input from the potentiometer (A0).
- Converts voltage into a 10-bit digital signal (0–1023).

### Key Functions

#### `void ADC_Init()`
- Selects ADC reference voltage  
- Selects ADC channel A0  
- Enables ADC hardware  

#### `uint16_t ADC_Read()`
- Starts a conversion  
- Waits for conversion complete  
- Returns 0–1023 result  

---

## 3. LCD Module (LCD.h / LCD.ino)

### Responsibilities
- Displays the system information:
  - Current value
  - LL and LH values
  - Alarm status

### Key Functions

#### `void LCD_Init()`
- Initializes LCD pins  
- Sets display mode  
- Clears the screen  

#### `void LCD_ShowValues(int value, int LL, int LH, String status)`
Prints the formatted system information, e.g.:

Value: 56
LL: 20 LH: 80
Status: NORMAL


---

## 4. Button Module (Buttons.ino)

### Responsibilities
- Reads user input from the navigation keypad (UP/DOWN/LEFT/RIGHT/SELECT).
- Applies software debouncing.
- Returns the button ID used by the main application.

### Key Functions

#### `int GetButton()`
Returns one of:

- `UP`
- `DOWN`
- `LEFT`
- `RIGHT`
- `SELECT`
- `NONE`

---

## 5. LED Alarm Logic (Inside Main.ino)

### Responsibilities
- Turns LED ON if value is **below LL** or **above LH**.
- Turns LED OFF when value is normal.

Implemented using:
digitalWrite(LED_PIN, HIGH);
digitalWrite(LED_PIN, LOW);

---

# Integration and Configuration

This chapter details how all modules are combined to form the complete system.

---

## 1. Project File Structure

1. Project File Structure

- Main.ino  
- ADC.h  
- ADC.ino  
- LCD.h  
- LCD.ino  
- Buttons.ino  


```plantuml
@startuml
package "CW2 Include Structure" {

    [Main.ino] .> [ADC.h] : includes
    [Main.ino] .> [LCD.h] : includes
    [Main.ino] .> [Buttons.h] : includes

    [ADC.ino] .> [ADC.h] : includes
    [LCD.ino] .> [LCD.h] : includes
    [Buttons.ino] .> [Buttons.h] : includes

    ' Optional internal interfaces (representing logical use)
    interface ADC_Interface
    interface LCD_Interface
    interface Btn_Interface

    note left of Main.ino
      Main module controls:
      - ADC reading
      - LCD update
      - Button handling
    end note

    Main.ino ..> ADC_Interface : uses ADC values
    Main.ino ..> LCD_Interface : sends display data
    Main.ino ..> Btn_Interface : reads input
}
@enduml

```


---

## 2. Include Structure

### Main.ino
#include "ADC.h"
#include "LCD.h"
#include "Buttons.h"

### ADC module
#include "ADC.h"

### LCD module
#include "LCD.h"

### Buttons module
#include <Arduino.h>


---

## 3. Configuration Parameters

| Parameter       | Description                                      |
|-----------------|--------------------------------------------------|
| ADC Channel     | A0 (potentiometer input)                         |
| LED Pin         | D3                                               |
| LCD Pins        | Defined in LCD.h                                 |
| Button Pins     | Defined in Buttons.ino                           |
| LL (Low Limit)  | User adjustable (0–100)                          |
| LH (High Limit) | User adjustable (0–100)                          |

---

## 4. Integration Summary

- **Main Application** drives the system logic.  
- **ADC Module** provides raw analog measurements from potentiometer.  
- **LCD Module** displays final processed output.  
- **Buttons Module** allows user interaction for adjusting system settings.  
- **LED Alarm Logic** provides real-time visual feedback.  

All modules interact cleanly through function calls, allowing easy testing and maintenance.

---
